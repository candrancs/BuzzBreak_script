<?php

// Isi Dengan Benar
$device_model = "A1603";
$app_version_code = 15;
$device_type = "android";
$facebook_user_id = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
$device_id = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
$facebook_access_token = "xxxxxxxxxxxxxxxxxxxxxxxx";
$visitor_id = 1118;


// Bagian Headers
$voyager_api_key = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
$buzzbreak_api_key = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
$buzzbreak_locale = "in_ID";


?>